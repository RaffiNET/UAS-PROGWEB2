<?php
$name='Algerian';
$type='TTF';
$desc=array (
  'Ascent' => 888,
  'Descent' => -224,
  'CapHeight' => 888,
  'Flags' => 4,
  'FontBBox' => '[-188 -259 1017 888]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 250,
);
$up=-118;
$ut=57;
$ttffile='MPDF57/ttfonts/algerian.ttf';
$TTCfontID='0';
$originalsize=69496;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='algerian';
$panose=' 0 0 4 2 7 5 4 a 2 6 7 2';
$haskerninfo=false;
$unAGlyphs=false;
?>