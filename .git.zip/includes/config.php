<?php
class Config{
	
	private $host = "localhost";
	private $db_name = "progra12_bengkel";
	private $username = "progra12_elan";
	private $password = "palapeyang926";
	public $conn;
	
	public function getConnection(){
	
		$this->conn = null;
		
		try{
			$this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
		}catch(PDOException $exception){
			echo "Connection error: " . $exception->getMessage();
		}
		
		return $this->conn;
	}
}
?>
