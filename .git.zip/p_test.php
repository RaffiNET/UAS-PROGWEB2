<?php

$banyak = $_POST['banyak'];
header("Location: test.php?banyak=$banyak");