
			  <div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><span class="fa fa-dashboard"></span> Dashboard</h3>
			  </div>
			  <div class="panel-body">
			    <ul class="nav nav-pills nav-stacked">
				  <li role="presentation"><a href="index.php"><span class="fa fa-home"></span> Beranda</a></li>
				</ul>
			  </div>
			</div>
		  	<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><span class="fa fa-file"></span> Input Data Bengkel</h3>
			  </div>
			  <div class="panel-body">
			    <ul class="nav nav-pills nav-stacked">
			      <li role="presentation"><a href="pembelian.php"><span class="fa fa-wrench"></span> Data Service</a></li>
				  <li role="presentation"><a href="sparepart.php"><span class="fa fa-cogs"></span> Data Sparepart</a></li>
				</ul>
			  </div>
			</div>
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><span class="fa fa-folder"></span> Layanan Pelanggan</h3>
			  </div>
			  <div class="panel-body">
			    <ul class="nav nav-pills nav-stacked">
				  <li role="presentation"><a href="pelanggan.php"><span class="fa fa-users"></span> Data Pelanggan</a></li>
				</ul>
			  </div>
			</div>
		  	<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><span class="fa fa-file"></span> Input Data Transaksi</h3>
			  </div>
			  <div class="panel-body">
			    <ul class="nav nav-pills nav-stacked">
				  
				  <li role="presentation"><a href="laporan-penjualan.php" target="_blank"><span class="fa fa-file-pdf-o"></span> Laporan Transaksi</a></li>
				</ul>
			  </div>
			</div>
		  	<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><span class="fa fa-database"></span> Petugas Area</h3>
			  </div>
			  <div class="panel-body">
			    <ul class="nav nav-pills nav-stacked">
			      <li role="presentation"><a href="mekanik.php"><span class="fa fa-users"></span> Data Mekanik</a></li>
				  <li role="presentation"><a href="profil.php"><span class="fa fa-user"></span> Profil</a></li>
				  <li role="presentation"><a href="user.php"><span class="fa fa-users"></span> Petugas</a></li>
				  <li role="presentation"><a href="login.php"><span class="fa fa-sign-out"></span> Logout</a></li>
				</ul>
			  </div>
			</div>